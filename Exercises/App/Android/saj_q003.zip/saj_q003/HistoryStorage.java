package jp.co.altoterras.fortune;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;

/**
 * 履歴クラス
 * 
 */
public class HistoryStorage
{
	//======================================================================
	// 定数

	private final static String FILE_NAME = "histry.txt"; 

	//======================================================================
	// クラス
	
	/**
	 * 結果クラス
	 * 
	 */
	public static class Result
	{
		public int _year;
		public int _month;
		public int _day;
		public int _rankTotal;
		public int _rankRomance;
		public int _rankMoney;
		public int _rankWork;
	}
	
	//======================================================================
	// 変数
	
	private ArrayList<String> _list;

	//======================================================================
	// メソッド
	
	/**
	 * コンストラクタ
	 * 
	 */
	public HistoryStorage()
	{
		_list = new ArrayList<String>();
	}
	
	/**
	 * 履歴データ数を得る
	 */
	public int getCount()
	{
		return _list.size();
	}
	
	/**
	 * 履歴を追加する
	 * 
	 */
	@SuppressLint("DefaultLocale")
	public void appendHistory(Result result)
	{
		String str = String.format("%d/%d/%d,%d,%d,%d,%d",
				result._year,
				result._month,
				result._day,
				result._rankTotal,
				result._rankRomance,
				result._rankMoney,
				result._rankWork);
		_list.add(str);
	}
	
	/**
	 * 履歴を得る
	 * 
	 */
	public boolean getHistroy(int index, Result result)
	{
		/* ★コメントアウトを外して、??? を埋めましょう
		if((index < 0) || (index >= _list.size()))
		{
			return false;
		}
		String str = _list.get(index);
		String[] elms = str.split(",", 0);
		if(elms.length != 5)
		{
			return false;
		}
		???
		if(ymd.length != 3)
		{
			return false;
		}
		result._year = ???
		result._month = ???
		result._day = ???
		result._rankTotal = Integer.parseInt(elms[1]);
		result._rankRomance = Integer.parseInt(elms[2]);
		result._rankMoney = Integer.parseInt(elms[3]);
		result._rankWork = Integer.parseInt(elms[4]);
		*/
		return true;
	}

	/**
	 * ファイルから読み込む
	 *
	 */
	public boolean readFromFile(Context ctx)
	{
		_list.clear();
		
		/* ★コメントアウトを外して、??? を埋めましょう
		try
		{
			???
			???
			Object obj = objstm.readObject();
			if(!(obj instanceof ArrayList))
			{
				return false;
			}
			@SuppressWarnings("unchecked")
			ArrayList<String> list = (ArrayList<String>)obj;
			???
		}
		catch (FileNotFoundException e)
		{
			return true;	// 問題ない
		}
		catch (StreamCorruptedException e)
		{
			e.printStackTrace();
			return false;
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return false;
		}
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
			return false;
		}
		catch (ClassCastException e)
		{
			e.printStackTrace();
			return false;
		}
		*/
		return true;
	}
	
	/**
	 * ファイルへ書き込む
	 *
	 */
	public boolean writeToFile(Context ctx)
	{
		try
		{
			FileOutputStream filestm = ctx.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
			ObjectOutputStream objstm = new ObjectOutputStream(filestm);
			objstm.writeObject(_list);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
			return false;
		}
		catch (StreamCorruptedException e)
		{
			e.printStackTrace();
			return false;
		}
		catch (IOException e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
