package jp.co.altoterras.fortune;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

/**
 * 占い結果表示アクティビティ
 * 
 */
public class HistoryActivity extends Activity
{
	//======================================================================
	// 変数
	
	private GridView _gridviewHistory;

	//======================================================================
	// メソッド
	
	/**
	 * 履歴表示の更新
	 * 
	 */
	@SuppressLint({ "UseValueOf", "SimpleDateFormat" })
	protected void updateHistory()
	{
		ArrayList<String> list = new ArrayList<String>();
		
		// ファイルから読み込む
		HistoryStorage hs = new HistoryStorage();
		hs.readFromFile(getApplicationContext());
		for(int i = 0; i < hs.getCount(); i++)
		{
			HistoryStorage.Result result = new HistoryStorage.Result();
			hs.getHistroy(i, result);
			list.add(result._year + "/" + result._month + "/" + result._day);
			list.add("総:" + result._rankTotal);
			list.add("恋:" + result._rankRomance);
			list.add("金:" + result._rankMoney);
			list.add("仕:" + result._rankWork);
		}
		
		 ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
		_gridviewHistory.setAdapter(adapter);
	}

	/**
	 * 作成イベントハンドラ
	 * 
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_history);

		// 変数と GUI リソースの関連付け
		_gridviewHistory = (GridView)this.findViewById(R.id.gridViewHistory);
		
		// 履歴表示の更新
		updateHistory();
	}

}
