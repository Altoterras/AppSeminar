package jp.co.altoterras.calcs;

/**
 * 浮動小数点数値クラス
 */
public class DoubleNumber extends Number
{
	//======================================================================
	// 変数

	double _d;

	//======================================================================
	// メソッド

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// アクセサ
	
	/**
	 * 値取得
	 */
	public double getValue()
	{
		return _d;
	}
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * コンストラクタ
	 */
	DoubleNumber()
	{
		_d = 0.0;
	}
	
	/**
	 * コンストラクタ
	 */
	DoubleNumber(double d)
	{
		_d = d;
	}

	/**
	 * 値をクリアした数値を生成
	 */
	@Override
	public Number clear()
	{
		return new DoubleNumber(0.0);
	}
	
	/**
	 * 文字列化
	 */
	public String toString()
	{
		return Double.toString(_d);
	}
	
	/**
	 * 文字列からの数値化
	 */
	public Number parse(String str)
	{
		try
		{
			return new DoubleNumber(Double.parseDouble(str));
		}
		catch(Exception ex)
		{
			System.out.printf(ex.getMessage());
			return new DoubleNumber(0.0);
		}
	}
}
