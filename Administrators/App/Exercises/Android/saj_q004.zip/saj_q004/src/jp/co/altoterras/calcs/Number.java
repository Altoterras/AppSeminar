package jp.co.altoterras.calcs;

/**
 * 数値抽象クラス
 */
public abstract class Number
{
	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * 値をクリアした数値を生成
	 */
	public abstract Number clear();
	
	/**
	 * 文字列化
	 */
	public abstract String toString();
	
	/**
	 * 文字列からの数値化
	 */
	public abstract Number parse(String str);
}
