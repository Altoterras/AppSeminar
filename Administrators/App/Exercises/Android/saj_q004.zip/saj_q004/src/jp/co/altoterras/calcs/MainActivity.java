package jp.co.altoterras.calcs;

import com.example.calcs.R;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * メインアクティビティ
 *
 */
public class MainActivity extends Activity implements View.OnClickListener
{
	//======================================================================
	// 定数
	
	private static final int BTN_0 = 0;
	private static final int BTN_1 = 1;
	private static final int BTN_2 = 2;
	private static final int BTN_3 = 3;
	private static final int BTN_4 = 4;
	private static final int BTN_5 = 5;
	private static final int BTN_6 = 6;
	private static final int BTN_7 = 7;
	private static final int BTN_8 = 8;
	private static final int BTN_9 = 9;
	private static final int BTN_DOT = 10;
	private static final int BTN_EQUAL = 11;
	private static final int BTN_PLUS = 12;
	private static final int BTN_MINUS = 13;
	private static final int BTN_MULT = 14;
	private static final int BTN_DIV = 15;
	private static final int BTN_CLEAR = 16;
	private static final int BTN_SIN = 17;
	private static final int BTN_COS = 18;
	private static final int BTN_NEXT = 19;
	private static final int BTN_MEMORY_CLEAR = 20;
	private static final int BTN_MEMORY_PLUS = 21;
	private static final int BTN_MEMORY_MINUS = 22;
	private static final int BTN_MEMORY_RESULT = 23;
	private static final int BTN_INT = 24;
	private static final int BTN_DOUBLE = 25;
	private static final int BTN_COMPLEX = 26;
	private static final int BTN_DECIMAL = 27;
	private static final int NUM_BTN = 28;
	
	//======================================================================
	// 変数

	private Calculator _calc = new IntCalculator();
	private Button[] _btns = new Button[NUM_BTN];
	private EditText _etxtDisplay = null;
	private String _strDisplay = new String();
	private int _op = NUM_BTN;
	private int _ibtnPrev = NUM_BTN;
	private int _radix = 10;
	
	//======================================================================
	// メソッド
	
	/**
	 * ボタンの表示更新
	 */
	private void updateButtons()
	{
		boolean isValidTriFunc = (_calc instanceof TriangleFunction);
		_btns[BTN_SIN].setVisibility(isValidTriFunc ? View.VISIBLE : View.INVISIBLE);
		_btns[BTN_SIN].setEnabled(isValidTriFunc);
		_btns[BTN_COS].setVisibility(isValidTriFunc ? View.VISIBLE : View.INVISIBLE);
		_btns[BTN_COS].setEnabled(isValidTriFunc);
		
		//_btns[BTN_NEXT].setVisibility(_calc instanceof ComplexCalculator ? View.VISIBLE : View.INVISIBLE);
		
		_btns[BTN_INT].setEnabled(!(_calc instanceof IntCalculator));
		_btns[BTN_DOUBLE].setEnabled(!(_calc instanceof DoubleCalculator));
		//_btns[BTN_COMPLEX].setEnabled(!(_calc instanceof ComplexCalculator));

		_btns[BTN_DECIMAL].setEnabled(_radix != 10);
	}
	
	/**
	 * 画面表示更新
	 */
	private void updateDisplay()
	{
		// テキストフィールドの更新
		_etxtDisplay.setText(_strDisplay, EditText.BufferType.NORMAL);
	}

	/**
	 * 作成イベントハンドラ
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		// ビューリソースを設定
		setContentView(R.layout.activity_main);
		
		// 変数とリソースを関連付ける
		_btns[BTN_0] = (Button)findViewById(R.id.button0);
		_btns[BTN_1] = (Button)findViewById(R.id.button1);
		_btns[BTN_2] = (Button)findViewById(R.id.button2);
		_btns[BTN_3] = (Button)findViewById(R.id.button3);
		_btns[BTN_4] = (Button)findViewById(R.id.button4);
		_btns[BTN_5] = (Button)findViewById(R.id.button5);
		_btns[BTN_6] = (Button)findViewById(R.id.button6);
		_btns[BTN_7] = (Button)findViewById(R.id.button7);
		_btns[BTN_8] = (Button)findViewById(R.id.button8);
		_btns[BTN_9] = (Button)findViewById(R.id.button9);
		_btns[BTN_DOT] = (Button)findViewById(R.id.buttonDot);
		_btns[BTN_EQUAL] = (Button)findViewById(R.id.buttonEqual);
		_btns[BTN_PLUS] = (Button)findViewById(R.id.buttonPlus);
		_btns[BTN_MINUS] = (Button)findViewById(R.id.buttonMinus);
		_btns[BTN_MULT] = (Button)findViewById(R.id.buttonMult);
		_btns[BTN_DIV] = (Button)findViewById(R.id.buttonDiv);
		_btns[BTN_CLEAR] = (Button)findViewById(R.id.buttonClear);
		_btns[BTN_SIN] = (Button)findViewById(R.id.buttonSin);
		_btns[BTN_COS] = (Button)findViewById(R.id.buttonCos);
		_btns[BTN_NEXT] = (Button)findViewById(R.id.buttonNext);
		_btns[BTN_MEMORY_CLEAR] = (Button)findViewById(R.id.buttonMemoryClear);
		_btns[BTN_MEMORY_PLUS] = (Button)findViewById(R.id.buttonMemoryPlus);
		_btns[BTN_MEMORY_MINUS] = (Button)findViewById(R.id.buttonMemoryMinus);
		_btns[BTN_MEMORY_RESULT] = (Button)findViewById(R.id.buttonMemoryResult);
		_btns[BTN_INT] = (Button)findViewById(R.id.buttonInt);
		_btns[BTN_DOUBLE] = (Button)findViewById(R.id.buttonDouble);
		_btns[BTN_COMPLEX] = (Button)findViewById(R.id.buttonComplex);
		_btns[BTN_DECIMAL] = (Button)findViewById(R.id.buttonDecimal);
		_etxtDisplay = (EditText)findViewById(R.id.edittextDisplay);
	
		// ボタンのイベントハンドラをこのアクティビティが拾う
		for(int i = 0; i < NUM_BTN; i++)
		{
			_btns[i].setOnClickListener(this);
		}
		
		// UI 更新
		updateButtons();
		updateDisplay();
	}

	/**
	 * オプションメニュー作成イベントハンドラ
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	/**
	 * クリックイベントハンドラ
	 */
	@Override
	public void onClick(View view)
	{
		int ibtn = 0;
		while(_btns[ibtn] != view)	{	ibtn++;	}

		if((BTN_0 <= ibtn) && (ibtn <= BTN_9))
		{
			if(isConcludedOp())	{	_strDisplay = "";	}
			_strDisplay += Integer.toString(ibtn - BTN_0);
			updateDisplay();
		}
		else if(ibtn == BTN_DOT)
		{
			if(isConcludedOp())	{	_strDisplay = "";	}
			_strDisplay += ".";
			updateDisplay();
		}
		else if(ibtn == BTN_NEXT)
		{
			if(isConcludedOp())	{	_strDisplay = "";	}
			_strDisplay += " + i";
			updateDisplay();
		}
		else if((BTN_PLUS <= ibtn) && (ibtn <= BTN_DIV))
		{
			_calc.setNumber(convDisplayStrToNum());
			_op = ibtn;
		}
		else if(ibtn == BTN_CLEAR)
		{
			doClear();
		}
		else if(ibtn == BTN_EQUAL)
		{
			doEqual();
		}
		else if((ibtn == BTN_SIN) || (ibtn == BTN_COS))
		{
			doTriangleFunc(ibtn);
		}
		else if((BTN_MEMORY_CLEAR <= ibtn) && (ibtn <= BTN_MEMORY_RESULT))
		{
			doMemory(ibtn);
		}
		else if((BTN_INT <= ibtn) && (ibtn <= BTN_COMPLEX))
		{
			changeNumberType(ibtn);
		}
		else if(ibtn == BTN_DECIMAL)
		{
			changeRadix(10);
		}
		
		_ibtnPrev = ibtn;
	}
	
	/**
	 * 一つ前の操作が完結したものかどうかを得る
	 */
	private boolean isConcludedOp()
	{
		if((BTN_0 <= _ibtnPrev) && (_ibtnPrev <= BTN_9))
		{
			return false;
		}
		if(_ibtnPrev == BTN_DOT)
		{
			return false;
		}
		if(_ibtnPrev == BTN_NEXT)
		{
			return false;
		}
		return true;
	}
	
	/**
	 * = 演算実行
	 */
	private void doEqual()
	{
		if(_op == BTN_PLUS)
		{
			_calc.add(convDisplayStrToNum());
		}
		else if(_op == BTN_MINUS)
		{
			_calc.sub(convDisplayStrToNum());
		}
		else if(_op == BTN_MULT)
		{
			_calc.mult(convDisplayStrToNum());
		}
		else if(_op == BTN_DIV)
		{
			_calc.div(convDisplayStrToNum());
		}
		
		_op = NUM_BTN;
		_strDisplay = convCalcNumToStr();
		updateDisplay();
	}
	
	/**
	 * メモリ機能実行
	 */
	private void doMemory(int ibtn)
	{
		if(ibtn == BTN_MEMORY_CLEAR)
		{
			_calc.memoryClear();
		}
		else if(ibtn == BTN_MEMORY_PLUS)
		{
			_calc.memoryAdd(convDisplayStrToNum());
		}
		else if(ibtn == BTN_MEMORY_MINUS)
		{
			_calc.memorySub(convDisplayStrToNum());
		}
		else if(ibtn == BTN_MEMORY_RESULT)
		{
			_calc.memoryResult();
			_strDisplay = convCalcNumToStr();
			updateDisplay();
		}
	}
	
	/**
	 * 三角関数実行
	 */
	private void doTriangleFunc(int ibtn)
	{
		if(!(_calc instanceof TriangleFunction))
		{
			return;
		}
		
		_calc.setNumber(convDisplayStrToNum());

		if(ibtn == BTN_SIN)
		{
			((TriangleFunction)_calc).sin();
		}
		else if(ibtn == BTN_COS)
		{
			((TriangleFunction)_calc).cos();
		}
	
		_strDisplay = convCalcNumToStr();
		updateDisplay();
	}
	
	/**
	 * クリア実行
	 */
	private void doClear()
	{
		if(_strDisplay.length() <= 0)
		{
			_op = NUM_BTN;
		}
		
		_strDisplay = "";
		updateDisplay();
	}
	
	/**
	 * 数値型変更
	 */
	private void changeNumberType(int ibtn)
	{
		_strDisplay = convCalcNumToStr();

		if(ibtn == BTN_INT)
		{
			if(!(_calc instanceof IntCalculator))
			{
				_calc = new IntCalculator();
			}
		}
		else if(ibtn == BTN_DOUBLE)
		{
			if(!(_calc instanceof DoubleCalculator))
			{
				_radix = 10;
				_calc = new DoubleCalculator();
			}
		}
		
		updateDisplay();
		updateButtons();
	}
	
	/**
	 * 基数変更
	 */
	private void changeRadix(int radix)
	{
		if(_radix == radix)
		{
			return;
		}
		
		_calc.setNumber(convDisplayStrToNum());

		_radix = radix;

		_strDisplay = convCalcNumToStr();
		updateDisplay();
		updateButtons();
	}
	
	/**
	 * 計算機の数値の文字列化
	 */
	public String convCalcNumToStr()
	{
		return _calc.getNumber().toString();
	}

	/**
	 * ディスプレイ文字列の数値化
	 */
	public Number convDisplayStrToNum()
	{
		return _calc.getNumber().parse(_strDisplay);
	}
}
