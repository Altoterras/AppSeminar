package jp.co.altoterras.calcs;

/**
 * 計算機抽象クラス
 */
public abstract class Calculator
{
	//======================================================================
	// 変数
	
	protected Number _numCur;
	protected Number _numMem;

	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// アクセサ
	
	/**
	 * 現在の数値取得
	 */
	public Number getNumber()
	{
		return _numCur;
	}
	
	/**
	 * 現在の数値設定
	 */
	public void setNumber(Number n)
	{
		_numCur = n;
	}
	
	/**
	 * メモリー数値取得
	 */
	public Number getMemoryNumber()
	{
		return _numMem;
	}

	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * 加算
	 */
	public abstract void add(Number n);

	/**
	 * 減算
	 */
	public abstract void sub(Number n);

	/**
	 * 乗算
	 */
	public abstract void mult(Number n);
	
	/**
	 * 徐算
	 */
	public abstract void div(Number n);
	
	/**
	 * メモリークリア
	 */
	public void memoryClear()
	{
		_numMem = _numMem.clear();
	}
	
	/**
	 * メモリー加算
	 */
	public abstract void memoryAdd(Number n);
	
	/**
	 * メモリー減算
	 */
	public abstract void memorySub(Number n);
	
	/**
	 * メモリー数値出力
	 */
	public void memoryResult()
	{
		_numCur = _numMem;
	}
}
