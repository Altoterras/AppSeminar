package jp.co.altoterras.calcs;

/**
 * 複素数数値クラス
 */
public class ComplexNumber extends Number
{
	//======================================================================
	// 変数

	private float _r;	// 実数値
	private float _i;	// 虚数値

	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// アクセサ
	
	/**
	 * 実数値取得
	 */
	public float getRealValue()
	{
		return _r;
	}
	
	/**
	 * 虚数値取得
	 */
	public float getImaginaryValue()
	{
		return _i;
	}
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * コンストラクタ
	 */
	public ComplexNumber()
	{
		_r = 0.0f;
		_i = 0.0f;
	}
	
	/**
	 * コンストラクタ
	 */
	public ComplexNumber(float r, float i)
	{
		_r = r;
		_i = i;
	}
	
	/**
	 * 値をクリアした数値を生成
	 */
	@Override
	public Number clear()
	{
		return new ComplexNumber(0.0f, 0.0f);
	}

	/**
	 * 文字列化
	 */
	@Override
	public String toString()
	{
		return Float.toString(_r) + " + i" + Float.toString(_i);
	}

	/**
	 * 文字列からの数値化
	 */
	@Override
	public Number parse(String str)
	{
		String strR = null;
		String strI = null;
		/*
		 
		 ★
		 "123 + i456" 形式の複素数表現文字列を解析しましょう！
		  このコメントを削除して、解析プログラムを完成させましょう

		try
		{
			String[] strRi = strRi.？？？;	// + で分割
			if(strRi.length >= 2)
			{
				strR = strRi[0].trim();
				strRi[1] = strRi[1].trim();
				if(？？？indexOf('i') == 0)
				{
					strI = strRi[1].substring(1);	// i を抜く
				}		
			}
			else if(strRi.length >= 1)
			{
				strRi[0] = strRi[0].trim();
				if(？？？indexOf('i') == 0)
				{
					strI = strRi[0].substring(1);	// i を抜く
				}
				else
				{
					strR = strRi[0];
				}
			}
		}
		catch(Exception ex)
		{
			System.out.printf(ex.getMessage());
		}
		*/
		
		float r = 0.0f;
		float i = 0.0f;
		try
		{
			if((strR != null) && (strR.length() >= 1))	{	r = Float.parseFloat(strR);	}
		}
		catch(Exception ex)
		{
			System.out.printf(ex.getMessage());
		}
		try
		{
			if((strI != null) && (strI.length() >= 1))	{	i = Float.parseFloat(strI);	}
		}
		catch(Exception ex)
		{
			System.out.printf(ex.getMessage());
		}

		return new ComplexNumber(r, i);
	}

}
