package jp.co.altoterras.calcs;

/**
 * 三角関数インターフェイス
 */
public interface TriangleFunction
{
	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * サイン
	 */
	public void sin();

	/**
	 * コサイン
	 */
	public void cos();
}
