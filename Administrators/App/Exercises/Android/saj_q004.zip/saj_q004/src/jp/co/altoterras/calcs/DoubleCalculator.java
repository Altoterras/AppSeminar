package jp.co.altoterras.calcs;

/**
 * 浮動小数点計算機クラス
 */
public class DoubleCalculator extends Calculator implements TriangleFunction
{
	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス

	/**
	 * コンストラクタ
	 */
	public DoubleCalculator()
	{
		_numCur = new DoubleNumber();
		_numMem = new DoubleNumber();
	}
	
	/**
	 * 値取得
	 */
	private static double getValue(Number n)
	{
		if(!(n instanceof DoubleNumber))	{	return 0.0;	}
		return ((DoubleNumber)n).getValue();
	}
	
	/**
	 * 加算
	 */
	@Override
	public void add(Number n)
	{
		_numCur = new DoubleNumber(getValue(_numCur) + getValue(n));
	}

	/**
	 * 減算
	 */
	@Override
	public void sub(Number n)
	{
		_numCur = new DoubleNumber(getValue(_numCur) - getValue(n));
	}

	/**
	 * 乗算
	 */
	@Override
	public void mult(Number n)
	{
		_numCur = new DoubleNumber(getValue(_numCur) * getValue(n));
	}

	/**
	 * 除算
	 */
	@Override
	public void div(Number n)
	{
		_numCur = new DoubleNumber(getValue(_numCur) / getValue(n));
	}

	/**
	 * サイン
	 */
	@Override
	public void sin()
	{
		_numCur = new DoubleNumber(Math.sin(getValue(_numCur) / 180.0 * Math.PI));
	}

	/**
	 * コサイン
	 */
	@Override
	public void cos()
	{
		_numCur = new DoubleNumber(Math.cos(getValue(_numCur) / 180.0 * Math.PI));
	}
	
	/**
	 * メモリー加算
	 */
	public void memoryAdd(Number n)
	{
		_numMem = new DoubleNumber(getValue(_numMem) + getValue(n)); 
	}
	
	/**
	 * メモリー減算
	 */
	public void memorySub(Number n)
	{
		_numMem = new DoubleNumber(getValue(_numMem) - getValue(n)); 
	}
}
