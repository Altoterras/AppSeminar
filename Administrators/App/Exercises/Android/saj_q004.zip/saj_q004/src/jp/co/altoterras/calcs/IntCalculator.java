package jp.co.altoterras.calcs;

/**
 * 整数計算機クラス
 */
public class IntCalculator extends Calculator
{
	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス

	/**
	 * コンストラクタ
	 */
	public IntCalculator()
	{
		_numCur = new IntNumber();
		_numMem = new IntNumber();
	}
	
	/**
	 * 値取得
	 */
	private static int getValue(Number n)
	{
		if(!(n instanceof IntNumber))	{	return 0;	}
		return ((IntNumber)n).getValue();
	}
	
	/**
	 * 加算
	 */
	@Override
	public void add(Number n)
	{
		_numCur = new IntNumber(getValue(_numCur) + getValue(n));
	}

	/**
	 * 減算
	 */
	@Override
	public void sub(Number n)
	{
		_numCur = new IntNumber(getValue(_numCur) - getValue(n));
	}

	/**
	 * 乗算
	 */
	@Override
	public void mult(Number n)
	{
		_numCur = new IntNumber(getValue(_numCur) * getValue(n));
	}

	/**
	 * 除算
	 */
	@Override
	public void div(Number n)
	{
		_numCur = new IntNumber(getValue(_numCur) / getValue(n));
	}
	
	/**
	 * メモリー加算
	 */
	public void memoryAdd(Number n)
	{
		_numMem = new IntNumber(getValue(_numMem) + getValue(n)); 
	}
	
	/**
	 * メモリー減算
	 */
	public void memorySub(Number n)
	{
		_numMem = new IntNumber(getValue(_numMem) - getValue(n)); 
	}
}
