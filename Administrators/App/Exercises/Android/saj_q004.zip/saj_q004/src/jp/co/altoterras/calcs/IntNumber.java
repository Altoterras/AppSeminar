package jp.co.altoterras.calcs;

/**
 * 整数数値クラス
 */
public class IntNumber extends Number
{
	//======================================================================
	// 変数

	private int _i;

	//======================================================================
	// メソッド
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// アクセサ
	
	/**
	 * 値取得
	 */
	public int getValue()
	{
		return _i;
	}
	
	// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// サービス
	
	/**
	 * コンストラクタ
	 */
	public IntNumber()
	{
		_i = 0;
	}
	
	/**
	 * コンストラクタ
	 */
	public IntNumber(int i)
	{
		_i = i;
	}
	
	/**
	 * 値をクリアした数値を生成
	 */
	@Override
	public Number clear()
	{
		return new IntNumber(0);
	}
	
	/**
	 * 文字列化
	 */
	@Override
	public String toString()
	{
		return Integer.toString(_i);
	}
	
	/**
	 * 文字列からの数値化
	 */
	@Override
	public Number parse(String str)
	{
		try
		{
			return new IntNumber(Integer.parseInt(str));
		}
		catch(Exception ex)
		{
			System.out.printf(ex.getMessage());
			return new IntNumber(0);
		}
	}
}
